<?php

return [

    'welcome' => "Welcome everybody to SUNSHINE's SHOP!",

];