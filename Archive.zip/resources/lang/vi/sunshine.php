<?php

return [

    'welcome' => "Chào mừng các bạn đến với cửa hàng Phúc Bích!",

];