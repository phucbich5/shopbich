@extends('backend.layout.master')

@section('title')
Trang quản trị hệ thống
@endsection

@section('feature-title')
Màn hình quản trị
@endsection

@section('feature-description')
Xem nhanh toàn hệ thống
@endsection

@section('content')

@endsection

@section('custom-css')
<style>
</style>
@endsection

@section('custom-scripts')
<script>
</script>
@endsection